
package views;


public class Main {
    public static void main(String args[]){
        FrmLogin telaPrincipal = new FrmLogin();
    }
}
